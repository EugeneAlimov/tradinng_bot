
from __future__ import annotations
from dataclasses import dataclass
import os
from decimal import Decimal

@dataclass
class RiskCfg:
    position_size_usd: Decimal = Decimal(os.getenv("RISK_POSITION_SIZE_USD", "50"))
    max_daily_loss: float = float(os.getenv("RISK_MAX_DAILY_LOSS", "0.03"))

@dataclass
class Settings:
    api_key: str = os.getenv("EXMO_API_KEY", "")
    api_secret: str = os.getenv("EXMO_API_SECRET", "")
    storage_path: str = os.getenv("STORAGE_PATH", "data/")
    default_pair: str = os.getenv("TRADING_PAIR", "DOGE_EUR")
    mode: str = os.getenv("TRADING_MODE", "paper")
    risk: RiskCfg = RiskCfg()

def get_settings() -> Settings:
    return Settings()
