from __future__ import annotations

import argparse
import json
import math
import time
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from typing import List, Dict, Any, Optional, Tuple

import matplotlib.pyplot as plt

from src.infrastructure.exchange.exmo_api import ExmoApi, ExmoCredentials
from src.config.settings import get_settings


# ───────────────────────── helpers ─────────────────────────
def _parse_time_hint(s: Optional[str]) -> Optional[int]:
    if not s:
        return None
    s = str(s).strip()
    try:
        if s.endswith(("h", "m", "d")):
            n = int(s[:-1])
            now = datetime.now(timezone.utc)
            if s.endswith("h"):
                return int((now - timedelta(hours=n)).timestamp())
            if s.endswith("m"):
                return int((now - timedelta(minutes=n)).timestamp())
            if s.endswith("d"):
                return int((now - timedelta(days=n)).timestamp())
    except Exception:
        pass
    try:
        return int(s)
    except Exception:
        pass
    try:
        dt = datetime.fromisoformat(s)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        else:
            dt = dt.astimezone(timezone.utc)
        return int(dt.timestamp())
    except Exception:
        return None


def _filter_time(rows: List[Dict[str, Any]], since_ts: Optional[int], until_ts: Optional[int]) -> List[Dict[str, Any]]:
    if since_ts is None and until_ts is None:
        return rows
    out = []
    for r in rows:
        ts = int(r.get("ts", r.get("date", 0)))
        if since_ts is not None and ts < since_ts:
            continue
        if until_ts is not None and ts > until_ts:
            continue
        out.append(r)
    return out


def _downscale_limits(start: int) -> list[int]:
    chain = [start, 300, 200, 150, 120, 100, 80, 60, 50, 40, 30, 20, 10]
    out = []
    for x in chain:
        if x > 0 and x not in out:
            out.append(x)
    return out


def _plot_equity(ts: List[int], eq: List[Decimal], pair: str, tf: str, path: str) -> None:
    plt.figure(figsize=(10, 3.2))
    plt.plot(ts, [float(x) for x in eq])
    plt.title(f"Backtest SMA — {pair} {tf}")
    plt.xlabel("ts")
    plt.ylabel("equity (quote)")
    plt.tight_layout()
    plt.savefig(path, dpi=120)
    plt.close()
    print(f"→ Chart saved to: {path}")


# ───────────────────────── data fetcher ─────────────────────────
def fetch_ohlcv_resilient(api: ExmoApi, pair: str, tf: str, limit: int, since: Optional[int],
                          until: Optional[int], debug: bool = False) -> List[Dict[str, Any]]:
    """Пробует ohlcv → kline → candles, даунскейлит limit при пустом ответе."""
    methods = (
        ("ohlcv", api.ohlcv, True),     # возвращает list[list]; нормализуем
        ("kline", api.kline, False),    # уже нормализовано как list[dict]
        ("candles", api.candles, False)
    )

    for lim in _downscale_limits(limit):
        for name, fn, is_matrix in methods:
            try:
                data = fn(pair=pair, timeframe=tf, limit=lim)
                if debug:
                    print(f"[debug] {name}({pair},{tf},{lim}) -> {len(data) if isinstance(data, list) else 'n/a'} bars")
                if not isinstance(data, list) or len(data) == 0:
                    continue

                # нормализация OHLCV-матрицы
                if is_matrix:
                    data = [{"ts": int(r[0]), "open": r[1], "high": r[2], "low": r[3], "close": r[4], "volume": r[5]}
                            for r in data]

                # фильтры времени
                data = _filter_time(data, since, until)
                if len(data) > 0:
                    return data
            except Exception as e:
                if debug:
                    print(f"[debug] {name} error: {repr(e)}")
                # возможный rate-limit — даём дыхнуть и повторим следующий метод/лимит
                time.sleep(0.25)
        # маленькая пауза между сериями попыток
        time.sleep(0.25)

    return []


# ───────────────────────── simple SMA logic ─────────────────────────
def sma(arr: List[Decimal], n: int) -> List[Optional[Decimal]]:
    out: List[Optional[Decimal]] = [None] * len(arr)
    s = Decimal("0")
    q = []
    for i, v in enumerate(arr):
        q.append(v)
        s += v
        if len(q) > n:
            s -= q.pop(0)
        if len(q) == n:
            out[i] = s / n
    return out


@dataclass
class BacktestResult:
    trades: int
    realized: Decimal
    unrealized: Decimal
    total: Decimal
    fees: Decimal
    position_base: Decimal
    equity_curve_ts: List[int]
    equity_curve_q: List[Decimal]


def run_sma_backtest(bars: List[Dict[str, Any]], fast: int, slow: int,
                     fee_bps: int, size_quote: Decimal) -> BacktestResult:
    closes = [Decimal(str(b["close"])) for b in bars]
    ts = [int(b["ts"]) for b in bars]
    fast_sma = sma(closes, fast)
    slow_sma = sma(closes, slow)

    pos = Decimal("0")
    cash_q = Decimal("0")
    fees_q = Decimal("0")
    trades = 0
    eq_ts, eq_q = [], []

    for i in range(len(bars)):
        price = closes[i]
        fs = fast_sma[i]
        ss = slow_sma[i]
        signal = None
        if fs is not None and ss is not None:
            if fs > ss and (i == 0 or not (fast_sma[i-1] and slow_sma[i-1] and fast_sma[i-1] > slow_sma[i-1])):
                signal = "buy"
            elif fs < ss and (i == 0 or not (fast_sma[i-1] and slow_sma[i-1] and fast_sma[i-1] < slow_sma[i-1])):
                signal = "sell"

        if signal == "buy":
            qty = (size_quote / price).quantize(Decimal("0.00000001"))
            fee = (size_quote * Decimal(fee_bps) / Decimal(10000)).quantize(Decimal("0.00000001"))
            cash_q -= size_quote + fee
            fees_q += fee
            pos += qty
            trades += 1

        elif signal == "sell" and pos > 0:
            size_q = (pos * price).quantize(Decimal("0.00000001"))
            fee = (size_q * Decimal(fee_bps) / Decimal(10000)).quantize(Decimal("0.00000001"))
            cash_q += size_q - fee
            fees_q += fee
            pos = Decimal("0")
            trades += 1

        # mark-to-market
        equity = cash_q + pos * price
        eq_ts.append(ts[i])
        eq_q.append(equity)

    realized = cash_q
    unrealized = pos * (closes[-1] if closes else Decimal("0"))
    total = realized + unrealized

    return BacktestResult(
        trades=trades,
        realized=realized,
        unrealized=unrealized,
        total=total,
        fees=fees_q,
        position_base=pos,
        equity_curve_ts=eq_ts,
        equity_curve_q=eq_q,
    )


# ───────────────────────── CLI ─────────────────────────
def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="backtest-cli", description="SMA backtest over EXMO or JSON OHLCV")
    p.add_argument("--source", choices=["exmo", "json"], required=True)
    p.add_argument("--pair", required=True)
    p.add_argument("--tf", required=True, help="1m/5m/15m/1h/4h/1d …")
    p.add_argument("--limit", type=int, default=300)
    p.add_argument("--since", type=str, default=None, help="epoch/ISO/rel (e.g. 24h)")
    p.add_argument("--until", type=str, default=None)

    p.add_argument("--json-path", type=str, default=None, help="when --source json")
    p.add_argument("--save-json", type=str, default=None, help="dump fetched bars")

    p.add_argument("--fast", type=int, default=8)
    p.add_argument("--slow", type=int, default=21)
    p.add_argument("--fee-bps", type=int, default=10)
    p.add_argument("--size-quote", type=str, default="100")

    p.add_argument("--plot", type=str, default=None)
    p.add_argument("--debug-fetch", action="store_true")
    return p


def main() -> None:
    args = build_parser().parse_args()
    pair = args.pair
    tf = args.tf
    since_ts = _parse_time_hint(args.since)
    until_ts = _parse_time_hint(args.until)

    # загрузка данных
    bars: List[Dict[str, Any]]
    if args.source == "json":
        if not args.json_path:
            raise SystemExit("--json-path is required for --source json")
        with open(args.json_path, "r", encoding="utf-8") as f:
            raw = json.load(f)
        bars = raw.get("ohlcv") or raw.get("candles") or raw.get("kline") or raw
        if isinstance(bars, dict):
            # возможно формат {'pair':..., 'ohlcv':[...]}
            for k in ("ohlcv", "candles", "kline"):
                if isinstance(bars.get(k), list):
                    bars = bars[k]
                    break
        if not isinstance(bars, list):
            raise SystemExit("JSON does not contain list of bars")
        bars = _filter_time(bars, since_ts, until_ts)

    else:
        # EXMO
        s = get_settings()
        api = ExmoApi(ExmoCredentials(s.api_key, s.api_secret), allow_trading=False)
        bars = fetch_ohlcv_resilient(api, pair, tf, args.limit, since_ts, until_ts, debug=args.debug_fetch)
        if args.save_json:
            try:
                with open(args.save_json, "w", encoding="utf-8") as f:
                    json.dump({"pair": pair, "tf": tf, "ohlcv": bars}, f, ensure_ascii=False, indent=2, default=str)
                print(f"→ JSON saved to: {args.save_json}")
            except Exception as e:
                print(f"⚠️  Failed to save JSON: {e!r}")

    if not bars:
        print("Не удалось получить OHLCV")
        return

    print(f"SMA backtest {pair} {tf}  bars={len(bars)}")
    res = run_sma_backtest(
        bars=bars,
        fast=args.fast,
        slow=args.slow,
        fee_bps=args.fee_bps,
        size_quote=Decimal(args.size_quote),
    )
    print(f"  trades: {res.trades}")
    print(f"  position: {res.position_base} {pair.split('_',1)[0]}")
    print(f"  realized: {res.realized}")
    print(f"  unrealized: {res.unrealized}")
    print(f"  total PnL: {res.total}")
    print(f"  fees (quote): {res.fees}")

    if args.plot:
        _plot_equity(res.equity_curve_ts, res.equity_curve_q, pair, tf, args.plot)


if __name__ == "__main__":
    main()
