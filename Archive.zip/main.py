
from src.presentation.cli.app import run_cli

if __name__ == "__main__":
    run_cli()
